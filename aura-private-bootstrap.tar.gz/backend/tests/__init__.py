"""
Test suite for AURA backend
"""

